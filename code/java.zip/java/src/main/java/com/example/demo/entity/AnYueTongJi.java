package com.example.demo.entity;

import lombok.Data;

/**
 * @author hui
 * @date 2022/9/1 17:23
 */
@Data
public class AnYueTongJi {
    private String type;

    private double yue1;

    private double yue2;

    private double yue3;

    private double yue4;

    private double yue5;

    private double yue6;

    private double yue7;

    private double yue8;

    private double yue9;

    private double yue10;

    private double yue11;

    private double yue12;

}
